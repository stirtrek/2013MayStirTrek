#I Didn't Know JavaScript Could Do That!#
###David Hoerster###

[My presentation in Prezi format](http://prezi.com/u82xiyo5o3wv/i-didnt-know-javascript-could-do-that/?kw=view-u82xiyo5o3wv&rc=ref-27746839).

Fun link from Gary Bernhardt on "[WAT](https://www.destroyallsoftware.com/talks/wat)" that really highlights some of the oddities of JavaScript.  Safe for work, but you'll laugh out loud.

*Thanks everyone for a great time at StirTrek 2013!*