Thanks for attending my StirTrek 2013 talk! 

If you're looking for the slides, they should be in this zip file over there (or maybe over there).

If you'd like to see some code examples, check out this repo on GitHub. I walk through building Facebook for Cats using Knockout and Backbone: https://github.com/jaredfaris/FacebookForCats

Thanks!
JaredTheNerd